package net.randomsync.googlesearch.tests;

public class Test1 {
public void testNo(){
	System.out.println("Testalone");
}
}
