
public class Fibo {
	/**
	 * @param n - interger value
	 * @return - total of the fibo series
	 */
	public static int fiboSeries(int n){
		if(n<=1){
			return n;
		}
		return(fiboSeries(n-1)+fiboSeries(n-2));
	}
	public static void main(String[] args) {
		int n=10;
		System.out.println(fiboSeries(n));
	}

}
