
public class fibbononrec {
	/**
	 * adding description to the method
	 * return - void
	 */
	public void findFibboMethod(){
		int f=0;
		int f1=-1;
		int f2=1;
		for(int i=1;i<=10;i++){
			f=f1+f2;
			f1=f2;
			f2=f;
			System.out.println(f2);
		}
	}
	public static void main(String[] args) {
		fibbononrec obj = new fibbononrec();
		obj.findFibboMethod();
		}
	}

