import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @author n041281
 *Purpose  - to compress the folder to a zip file
 *additional comments
 *
 *
 */
public class FileCompression {
	public static void pack(String sourceDirPath, String zipFilePath) throws IOException {
	    Path p = Files.createFile(Paths.get(zipFilePath));
	    try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p))) {
	        Path pp = Paths.get(sourceDirPath);
	        Files.walk(pp)
	          .filter(path -> !Files.isDirectory(path))
	          .forEach(path -> {
	              ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
	              try {
	                  zs.putNextEntry(zipEntry);
	                  Files.copy(path, zs);
	                  zs.closeEntry();
	            } catch (IOException e) {
	                System.err.println(e);
	            }
	          });
	    }
	}
	public static void main(String[] args) throws IOException {
		pack("//corp/sites/RIB1001/remote-infosys/Z_Naren/Screenshots/Admin Module/Naren/NACHA/Payroll", "//corp/sites/RIB1001/remote-infosys/Z_Naren/Screenshots/Admin Module/Naren/NACHA/NewFolder.zip");
	}
}
