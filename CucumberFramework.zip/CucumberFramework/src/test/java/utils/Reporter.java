package utils;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

//import org.apache.log4j.Logger;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

//import atu.alm.wrapper.enums.StatusAs;

public abstract class Reporter {
	public ExtentTest test;
	public static ExtentReports extent;
	public String testCaseName, testDescription, categories, authors;

/*	private static StatusAs ALMStatusToUpadate;
	static Logger logger = Logger.getLogger(Reporter.class.getName());
	*/
	public void reportStep(String desc, String status) {

		long snapNumber = 100000l;
		
		
		try {
			snapNumber= takeSnap();
		} catch (Exception e) {
			//
			//e.printStackTrace();
			//logger.info("Error at Reports "+e.getMessage());
		}
		
		// Write if it is successful or failure or information
		if(status.toUpperCase().equals("PASS")){
			test.log(LogStatus.PASS, desc+test.
					addScreenCapture("./../reports/images/"+snapNumber+".jpg"));
			//setAlmStatus(StatusAs.PASSED);
		//	logger.info(LogStatus.PASS+">>"+ desc);
			//ALMStatusToUpadate=StatusAs.PASSED;
		}else if(status.toUpperCase().equals("FAIL")){
			test.log(LogStatus.FAIL, desc+test.addScreenCapture("./../reports/images/"+snapNumber+".jpg"));
			//setAlmStatus(StatusAs.FAILED);
			//logger.info(LogStatus.FAIL+">>"+ desc);
			//throw new RuntimeException("FAILED");
		}else if(status.toUpperCase().equals("INFO")){
			//logger.info(LogStatus.INFO+">>"+ desc);
			test.log(LogStatus.INFO, desc);
		}
	}

	public abstract long takeSnap();
/*	
	public StatusAs getAlmStatus(){
		return ALMStatusToUpadate;
		
	}
	public void setAlmStatus(StatusAs status){
		ALMStatusToUpadate = status;
		
	}*/

	public ExtentReports startResult(){
		try {
		
			extent = new ExtentReports("./reports/result_"+reportAppendDate()+".html",true);
			//extent.loadConfig(new File("./extent-config.xml"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return extent;
	}

	public ExtentTest startTestCase(String testCaseName, String testDescription){
		test = extent.startTest(testCaseName, testDescription);
		return test;
	}

	public void endResult(){		
		extent.flush();
	}

	public void endTestcase(){
		
		extent.endTest(test);
		//System.out.println(test.getTest().getStatus());
		
	}

	
	public String reportAppendDate(){
		String dynamicValue=null;
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyyhhmmss");
		dynamicValue = sdf.format(date).toString();
		return dynamicValue;
	}

	
	
	public void createRunTimePropertyFile(){
		
		FileOutputStream fis  = null;
		try {
			fis = new FileOutputStream(new java.io.File("./RunTimeConfig.properties"));
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				fis.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

public void reportStep(String desc, String status,String screenShotRequired) {

		long snapNumber = 100000l;
		
		
		try {
			snapNumber= takeSnap();
		} catch (Exception e) {
			//
			//e.printStackTrace();
			System.out.println("Error occured in report step:::"+e.getMessage());
		}
		
		// Write if it is successful or failure or information
		if(status.toUpperCase().equals("PASS")){
			test.log(LogStatus.PASS, desc+test.
					addScreenCapture("./../reports/images/"+snapNumber+".jpg"));
		}else if(status.toUpperCase().equals("FAIL")){
			test.log(LogStatus.FAIL, desc+test.addScreenCapture("./../reports/images/"+snapNumber+".jpg"));
			//throw new RuntimeException("FAILED");
		}else if(status.toUpperCase().equals("INFO")){
			test.log(LogStatus.INFO, desc);
		}
	}
	
}
